const pets = [
  {
    id: 0,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Inuyasha",
  },

  {
    id: 1,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Sesshomaru",
  },

  {
    id: 2,
    species: "cat",
    eating_habit: "carnivore",
    pet_name: "Hunti",
  },

  {
    id: 3,
    species: "cat",
    eating_habit: "omnivore",
    pet_name: "Yuri",
  },

  {
    id: 0,
    species: "bird",
    eating_habit: "herbivore",
    pet_name: "Chimk",
  },
];

module.exports = { pets };
