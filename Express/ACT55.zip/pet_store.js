const pets = [
  {
    id: 0,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Inuyasha",
    image: "images/inuyasha.jpg",
  },

  {
    id: 1,
    species: "dog",
    eating_habit: "omnivore",
    pet_name: "Sesshomaru",
    image: "images/sesshomaru.jpg",
  },

  {
    id: 2,
    species: "cat",
    eating_habit: "carnivore",
    pet_name: "Hunti",
    image: "images/hunti.jpg",
  },

  {
    id: 3,
    species: "cat",
    eating_habit: "omnivore",
    pet_name: "Yuri",
    image: "images/yuri.jpg",
  },

  {
    id: 4,
    species: "bird",
    eating_habit: "herbivore",
    pet_name: "Chimk",
    image: "images/chimk.jpg",
  },
];

module.exports = { pets };
